# NOVIQ World v1 — Living Enterprise City

This package adds a **visual world layer** to the existing NOVIQ backend. It does not replace the business engine.

## What it adds
- `/world/` — interactive isometric city view
- Existing NOVIQ agents rendered as NPCs
- Departments rendered as buildings
- Agent status visualization: working / learning / idle / stopped
- Real NOVIQ revenue/profit/agent/event data pulled from the existing API
- Live event feed
- Clickable NPC inspection panel
- Pan + zoom
- Simulation clock for presentation/visualization

## Important
The NPC movement is a visualization layer. It does **not** claim an agent performed an action merely because an animation is playing. The source of truth remains NOVIQ's backend state and event system.

## GitHub Copilot merge recommendation
Copy the `public/world/` directory into the repository root's `public/world/` directory. Do not delete existing `public/app.js`, `public/index.html`, `server.js`, or database files.

Then deploy. Visit:

`https://YOUR-DOMAIN/world/`

The world UI uses the existing authenticated `/api/state` and `/api/metrics` endpoints.

## Optional next integration
Add a `WORLD` button to the existing Command Center linking to `/world/`. This is intentionally left as a tiny integration change so it doesn't overwrite Claude's current NOVIQ UI.
